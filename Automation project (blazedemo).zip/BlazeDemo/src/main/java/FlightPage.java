import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class FlightPage {
    private WebDriver driver;

    private By DepartureDropdown = By.name("fromPort");
    private By DestinationeDropdown = By.name("toPort");
    private By FlightButton = By.cssSelector("input[type='submit']");

    public FlightPage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectdeparturecountry(String country) {
        WebElement dropdown = driver.findElement(DepartureDropdown);
        Select option = new Select(dropdown);
        option.selectByVisibleText(country);

        Boolean x = dropdown.isDisplayed();
        System.out.println(x);

    }

    public void selectdestinationcountry(String country) {
        WebElement dropdown = driver.findElement(DestinationeDropdown);
        Select option = new Select(dropdown);
        option.selectByVisibleText(country);

        Boolean xx = dropdown.isDisplayed();
        System.out.println(xx);
    }

    public void findflightbutton() {
        WebElement flightclickbutton = driver.findElement(FlightButton);
        flightclickbutton.click();
    }
    public String getSelectedDepartureCountry() {
        WebElement dropdown = driver.findElement(DepartureDropdown);
        Select option = new Select(dropdown);
        return option.getFirstSelectedOption().getText();
    }

    // Method to get the currently selected destination country
    public String getSelectedDestinationCountry() {
        WebElement dropdown = driver.findElement(DestinationeDropdown);
        Select option = new Select(dropdown);
        return option.getFirstSelectedOption().getText();
    }

    // Method to click the find flight button
    public void clickFindFlight() {
        WebElement button = driver.findElement(FlightButton);
        button.click();
    }

}
