import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class PurchaseFlight {
    WebDriver driver;

    private By NameField = By.id("inputName");
    private By AddressField = By.id("address");
    private By CityField = By.id("city");
    private By StateField = By.id("state");
    private By ZipCodeField = By.id("zipCode");
    private By CardTypeField = By.id("cardType");
    private By CreditCardNumberField = By.id("creditCardNumber");
    private By MonthField = By.id("creditCardMonth");
    private By yearField = By.id("creditCardYear");
    private By NameOnCardField = By.id("nameOnCard");
    private By CheckboxField = By.id("rememberMe");
    private By PurchaseButtonField = By.xpath("/html/body/div[2]/form/div[11]/div/input");


    public PurchaseFlight (WebDriver driver) {
        this.driver=driver;
    }

    public void entername (String name) {
        WebElement n = driver.findElement(NameField);
        n.sendKeys(name);
        boolean nn = n.isDisplayed();
        boolean nnn = n.isEnabled();
        System.out.println(nn);
        System.out.println(nnn);


    }

    public void enteraddress (String address) {
        WebElement a = driver.findElement(AddressField);
        a.sendKeys(address);
        boolean aa = a.isDisplayed();
        boolean aaa = a.isEnabled();
        System.out.println(aa);
        System.out.println(aaa);
    }
    public void entercity (String city) {
        WebElement c = driver.findElement(CityField);
        c.sendKeys(city);
        boolean cc = c.isDisplayed();
        boolean ccc = c.isEnabled();
        System.out.println(cc);
        System.out.println(ccc);
    }

    public void enterstate (String state) {
        WebElement s = driver.findElement(StateField);
        s.sendKeys(state);
        boolean ss = s.isDisplayed();
        boolean sss = s.isEnabled();
        System.out.println(ss);
        System.out.println(sss);
    }

    public void enterzipcode (String zip) {
        WebElement z = driver.findElement(ZipCodeField);
        z.sendKeys(zip);
        boolean zz = z.isDisplayed();
        boolean zzz = z.isEnabled();
        System.out.println(zz);
        System.out.println(zzz);
    }
    public void cardtypedropdown (String card) {
        WebElement dropdown = driver.findElement(CardTypeField);
        Select option = new Select(dropdown);
        option.selectByVisibleText(card);
        Boolean dbutton = dropdown.isDisplayed();
        System.out.println(dbutton);
    }
    public void entercreditcardnumber (String credit) {
        WebElement cn = driver.findElement(CreditCardNumberField);
        cn.sendKeys(credit);
        boolean cnn= cn.isDisplayed();
        boolean cnnn  = cn.isEnabled();
        System.out.println(cnn);
        System.out.println(cnnn);
    }

    public void entermonth (String month) {
        WebElement month1 = driver.findElement(MonthField);
        month1.sendKeys(month);
        boolean m= month1.isDisplayed();
        boolean mm= month1.isEnabled();
        System.out.println(m);
        System.out.println(mm);
    }

    public void enteryear (String year) {
        WebElement y = driver.findElement(yearField);
        y.sendKeys(year);

        boolean yy = y.isDisplayed();
        boolean yyy = y.isEnabled();
        System.out.println(yy);
        System.out.println(yyy);
    }

    public void enternameoncard (String namecard) {
        WebElement nc = driver.findElement(NameOnCardField);
        nc.sendKeys(namecard);
        boolean ncc = nc.isDisplayed();
        boolean nccc= nc.isEnabled();
        System.out.println(ncc);
        System.out.println(nccc);
    }

    public void setCheckboxField () {
        WebElement checkbox = driver.findElement(CheckboxField);
        checkbox.click();
        Boolean xx = checkbox.isDisplayed();
        System.out.println(xx);

    }
    public void clickonpurchasebutton () {
        WebElement purchasebutton = driver.findElement(PurchaseButtonField);
        purchasebutton.click();



    }
}


