import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class ChooseFlightPageTest {
    WebDriver driver;

    @BeforeTest
    public void openbrowser() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://www.blazedemo.com/reserve.php");
    }

    @Test
    public void validatechoosebuttonisclickable() {
        WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
        ChooseFlightPage chooseFlightPage= new  ChooseFlightPage(driver);
        //wait.until(ExpectedConditions.visibilityOfElementLocated(chooseFlightPage.getchooseflightbutton()) );
        chooseFlightPage.clickonChooseFlightButton();
        String expectedUrl = "https://www.blazedemo.com/purchase.php"; // Replace with the actual expected URL
        String currentUrl = driver.getCurrentUrl();
        Assert.assertEquals(currentUrl, expectedUrl, "The user is not redirected to the expected purchase page!.");


    }
    @AfterTest
    public void closebrowser () {

          driver.quit();
        }
    }