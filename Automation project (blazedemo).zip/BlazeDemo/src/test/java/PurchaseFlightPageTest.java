import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PurchaseFlightPageTest {
    WebDriver driver;

    @BeforeTest
    public void openbrowser () {
        WebDriverManager.chromedriver().setup();
        driver=new ChromeDriver();
        driver.get("https://www.blazedemo.com/purchase.php");
    }

    @Test
    public void validatefields () {
        PurchaseFlight purchaseflight = new PurchaseFlight (driver);
        purchaseflight.entername("jonir samir");
        purchaseflight.enteraddress("nasr city");
        purchaseflight.entercity("cairo");
        purchaseflight.enterstate("egypt");
        purchaseflight.enterzipcode("0000");
        purchaseflight.cardtypedropdown("Visa");
        purchaseflight.entercreditcardnumber("273293923020");
        purchaseflight.entermonth("10");
        purchaseflight.enteryear("1999");
        purchaseflight.enternameoncard("jonir");
        purchaseflight.setCheckboxField();
        purchaseflight.clickonpurchasebutton();







        String expectedUrl = "https://www.blazedemo.com/confirmation.php";
        String actualUrl = driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl);


        String confirmationMessage = driver.findElement(By.cssSelector("body > div.container > div > h1")).getText();
        Assert.assertTrue(confirmationMessage.contains("Thank you for your purchase today!"));


    }

    @AfterTest
    public void closebrowser () {

        driver.quit();
    }

}
