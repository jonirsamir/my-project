import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.build.Plugin;
import org.apache.hc.core5.reactor.Command;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class FlightPageTest {
    WebDriver driver;

    @BeforeTest
    public void openbrowser () {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://www.blazedemo.com/");
    }



    @Test
    public void testflightpage () {
        FlightPage flightpage = new FlightPage(driver);
        flightpage.selectdeparturecountry("Paris");
        flightpage.selectdestinationcountry("London");
        flightpage.findflightbutton();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));



        String expectedUrl = "https://www.blazedemo.com/reserve.php";
        String actualUrl = driver.getCurrentUrl();
        Assert.assertEquals(actualUrl, expectedUrl,
                "The user is not redirected to the expected reserve page!");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }

   @Test
   public void testValidCountrySelection() {
       FlightPage flightPage = new FlightPage(driver);

       // Select countries
       flightPage.selectdeparturecountry("Paris");
       flightPage.selectdestinationcountry ("London");

       // Validate selections
       String selectedDeparture = flightPage.getSelectedDepartureCountry();
       String selectedDestination = flightPage.getSelectedDestinationCountry();

       Assert.assertEquals(selectedDeparture, "Paris", "Departure country not selected correctly!");
       Assert.assertEquals(selectedDestination, "London", "Destination country not selected correctly!");

       // Click the find flight button
       flightPage.clickFindFlight();
   }

   @AfterTest
    public void closebrowser () {

          driver.quit();
      }
  }


